

@
## Dev
1. Executar ```npm install```
2. Aixecar el backend de proves ```npm run backend```
3. Executar l'app ```ng serve -o```


Per iniciar sessió:
  1. Email: prova@prova.com
  2. Contrasenya: C0ntr4

Fins que no s'implmenti el backend amb nestjs, com a backend de proves s'utilitza ```json-server```.
El fitxer de base de dades és a ````data/db.json````
