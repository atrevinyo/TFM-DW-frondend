



export const environments = {
  baseURL: "https://servidor de produccio/api"
}
