

export const environments = {
  baseURL: "http://localhost:3000"
}
