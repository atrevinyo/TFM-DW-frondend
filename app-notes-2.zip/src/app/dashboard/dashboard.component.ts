import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Assignatura } from '../models/models';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { AssignaturesService } from '../services/assignatures.service';
import { MenusuperiorComponent } from '../menusuperior/menusuperior.component';
import { AssignaturaListComponent } from '../assignatura-list/assignatura-list.component';
import { AssignaturaComponent } from '../assignatura/assignatura.component';
import { AssignaturaFormComponent } from '../assignatura-form/assignatura-form.component';
import { AssignaturaCardComponent } from '../assignatura-card/assignatura-card.component';  // Import del nou component
import { ToastrService } from 'ngx-toastr';
import { ChangeDetectorRef } from '@angular/core';



@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  standalone: true,
  imports: [CommonModule, RouterModule, MenusuperiorComponent, AssignaturaComponent, AssignaturaListComponent, AssignaturaComponent, AssignaturaFormComponent, AssignaturaCardComponent],
})
export class DashboardComponent implements OnInit {

  public assignatures: Assignatura[] = [];
  // assignaturaSeleccionada?: Assignatura;
  modalObert = false;
  assignaturaAEditar: Assignatura | null = null;
  mostrarAssignaturaList: boolean = true;


  constructor(private assignaturesService: AssignaturesService, private router: Router,  private route: ActivatedRoute, private toastr: ToastrService, private cdr: ChangeDetectorRef) { }

  ngOnInit(): void {
    this.assignaturesService.getAssignatures()
      .subscribe(assignatures => this.assignatures = assignatures);

      this.route.url.subscribe((urlSegment) => {
        // Si la ruta és exactament `/dashboard`, mostra la llista d'assignatures
        this.mostrarAssignaturaList = this.router.url === '/dashboard';
      });
    }


  // Obre el modal per afegir o editar una assignatura
  obrirModalPerAfegirAssignatura(): void {
    this.assignaturaAEditar = null;  // Passa null per indicar que afegirem una assignatura nova
    this.modalObert = true;  // Obre el modal
  }

  // Tanca el modal
  tancarModal(): void {
    this.modalObert = false;
    this.assignaturaAEditar = null;
  }

  // Observer reutilitzable per a addAssignatura i updateAssignatura
  observer = {
    next: (response: Assignatura) => {
      this.toastr.success('Acció realitzada correctament');
      this.cdr.detectChanges();
    },
    error: (error: any) => {
      this.toastr.error('Error en l\'operació', 'Error');
    },
    complete: () => {
    }
  };

  // Afegeix una nova assignatura
  afegirAssignatura(assignatura: Assignatura): void {
    console.log("ESTIC AFEGINNT!!!!!")
    const novaAssignatura: Assignatura = {
      id: (this.assignatures.length + 1).toString(),
      nom: assignatura.nom,
      alumnes: [],
      activitats: []
    };
    this.assignatures = [...this.assignatures, novaAssignatura];
    this.assignaturesService.addAssignatura(novaAssignatura).subscribe(this.observer);
  }


  guardarAssignaturaEditada(assignatura: Assignatura): void {
    console.log("ESTIC EDITANT!!!!!")
    this.assignaturesService.updateAssignatura(assignatura).subscribe(this.observer)
    const index = this.assignatures.findIndex(a => a.id === assignatura.id);
    if (index !== -1) {
      this.assignatures[index] = assignatura; // Actualitza assignatura a la llista
    }

  }

  // Mètode per guardar una assignatura (sigui nova o editada)
  guardarAssignatura(assignatura: Assignatura): void {
    if (assignatura?.id) {
      // Si estem editant, actualitzem l'assignatura
      this.guardarAssignaturaEditada(assignatura);
    } else {
      // Si estem afegint una nova assignatura
      this.afegirAssignatura(assignatura);
    }
  }
  // Edició d'una assignatura
  editarAssignatura(assignatura: Assignatura): void {
    this.assignaturaAEditar = { ...assignatura };
    this.modalObert = true;
  }

  eliminarAssignatura(assignatura: Assignatura): void {
    this.assignatures = this.assignatures.filter(a => a.id !== assignatura.id);
    this.assignaturesService.deleteAssignaturaById(assignatura.id).subscribe(this.observer);
  }

  seleccionarAssignatura(assignatura: Assignatura): void {
    // this.assignaturaSeleccionada = assignatura;
    console.log(assignatura);
    this.router.navigate([`/dashboard/assignatura`, assignatura.id]); // Navega a la ruta de detall d'assignatura
  }
}
