import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { environments } from '../../environments/environments';
import { User } from '../models/models';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private baseUrl = environments.baseURL;
  private user?: User;

  constructor(private http: HttpClient, private router: Router) {}

  // Funció de login
  login(email: string, password: string): Observable<boolean> {
    return this.http.get<{ email: string; password: string; token: string }>(`${this.baseUrl}/users/1`).pipe(
      map(response => {
        // Comparar les credencials introduïdes amb les obtingudes del backend
        if (response.email === email && response.password === password) {
          localStorage.setItem('token', "asdasdASDFsdfsdFSFSDFSF"); // Token temporal per fer proves. Guarda el token a localStorage
          return true; // Login correcte
        } else {
          return false; // Login incorrecte
        }
      }),
      catchError(() => of(false)) // En cas d'error retorna false
    );
  }

  // Funció de logout
  logout() {
    localStorage.removeItem('token');
    this.router.navigate(['/login']);
  }


  // Comprova si l'usuari està autenticat
  isAuthenticated(): boolean {
    return !!localStorage.getItem('token');
  }
}
