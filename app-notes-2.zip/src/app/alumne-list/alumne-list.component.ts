import { Component, ElementRef, HostListener, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import {  Alumne } from '../models/models';

@Component({
  selector: 'app-alumne-list',
  templateUrl: './alumne-list.component.html',
  styleUrls: ['./alumne-list.component.css'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
})
export class AlumneListComponent implements OnInit {
  @Input() alumnes!: Alumne[];
  alumneSeleccionat?: Alumne;
  mostraFormulari: boolean = false;
  alumneForm: FormGroup;

  constructor(private fb: FormBuilder, private eRef: ElementRef) {
    this.alumneForm = this.fb.group({
      nom: ['']
    });
  }

  ngOnInit(): void {
    // Inicialitza mostrarMenu per cada alumne quan es carrega la llista
    this.alumnes.forEach(alumne => {
      alumne.mostrarMenu = false;
    });
  }


  // Mostrar o amagar el menú de tres punts
  toggleMenu(alumne: Alumne): void {
    // Amaga el menú dels altres alumnes i alterna l'alumne seleccionat
    this.alumnes.forEach(a => {
      if (a !== alumne) {
        a.mostrarMenu = false;
      }
    });
    alumne.mostrarMenu = !alumne.mostrarMenu;  // Alterna mostrarMenu per l'alumne seleccionat
  }

  // Mostra el formulari per afegir un nou alumne
  afegirAlumne() {
    this.alumneSeleccionat = undefined;
    this.mostraFormulari = true;
    this.alumneForm.reset();
  }

  // Mostra el formulari per editar un alumne
  editarAlumne(alumne: Alumne) {
    this.alumneSeleccionat = { ...alumne };
    this.alumneForm.patchValue(alumne);
    this.mostraFormulari = true;
  }

  // Guarda l'alumne (afegir o actualitzar)
  guardarAlumne() {
    if (this.alumneForm.valid) {
      const nom = this.alumneForm.get('nom')?.value;

      if (this.alumneSeleccionat) {
        // Actualització de l'alumne existent
        const index = this.alumnes.findIndex(a => a.id === this.alumneSeleccionat!.id);
        if (index !== -1) {
          this.alumnes[index] = { ...this.alumnes[index], nom };
        }
      } else {
        // Afegir nou alumne
        const nouId = (this.alumnes.length + 1).toString();
        this.alumnes.push({ id: nouId, nom, notes: [] });
      }

      this.mostraFormulari = false;
      this.alumneForm.reset();
    }
  }

  // Cancel·la l'operació d'afegir o editar
  cancelar() {
    this.mostraFormulari = false;
    this.alumneForm.reset();
  }

  // Elimina un alumne de l'assignatura
  eliminarAlumne(alumne: Alumne) {
    this.alumnes = this.alumnes.filter(a => a.id !== alumne.id);
  }

  // Listener per detectar clics fora del menú
  @HostListener('document:click', ['$event'])
  onClick(event: Event): void {
    const targetElement = event.target as HTMLElement;
    const clickedInside = this.eRef.nativeElement.contains(targetElement);

    if (!clickedInside) {
      // Tanca tots els menús quan es fa clic fora del component
      this.alumnes.forEach(alumne => {
        alumne.mostrarMenu = false;
      });
    }
  }
}
