// Interface Alumne
export interface Alumne {
  id: string;
  nom: string;
  mostrarMenu?: boolean;  // Propietat opcional per mostrar el menú
  notes: Nota[]; // Afegeix les notes de l'alumne
}

export interface Competencies {
  id: string;
  codi: string,
  nom: string,
  descripcio: string
}

// Interface Activitat
export interface Activitat {
  id: string;
  nom: string;
  descripcio: string;
  data: Date;
  competencies: Competencies[]
}


// Interface Assignatura
export interface Assignatura {
  id: string;
  nom: string;
  alumnes: Alumne[];
  activitats: Activitat[];
}


// Interface Nota
export interface Nota {
  activitatId: string;
  competenciaId: string;
  valor: number; 
}

export interface User {
      id: number;
      nom: string;
      email: string;
      password: string
}

