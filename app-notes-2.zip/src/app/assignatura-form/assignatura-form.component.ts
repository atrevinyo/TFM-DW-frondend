import { Component, EventEmitter, Input, Output, OnInit } from '@angular/core';
import { FormGroup, Validators, ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Assignatura } from '../models/models';

@Component({
  selector: 'app-assignatura-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './assignatura-form.component.html',
  styleUrls: ['./assignatura-form.component.css']
})

export class AssignaturaFormComponent implements OnInit {
  @Input() assignatura: Assignatura | null = null;
  @Output() onAssignaturaAfegida = new EventEmitter<Assignatura>(); // Envia el nom de la nova assignatura
  @Output() onTancar = new EventEmitter<void>(); // Emet l'event per tancar el modal

  assignaturaForm: FormGroup;



  constructor(private formBuilder: FormBuilder) {

    this.assignaturaForm = this.formBuilder.group({
      id: [],
      nom: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    if (this.assignatura) {
     this.assignaturaForm.patchValue({
       id: this.assignatura.id,
       nom: this.assignatura.nom
     });
   }
  }

  afegirAssignatura(): void {
    if (this.assignaturaForm.valid) {
      this.onAssignaturaAfegida.emit(this.assignaturaForm.value);
      this.tancarModal();
    }
  }

  tancarModal(): void {
    this.onTancar.emit();
  }
}
