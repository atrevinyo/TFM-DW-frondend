import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AuthGuard } from './auth.guard';
import { AssignaturaComponent } from './assignatura/assignatura.component';

export const routes: Routes = [

  // Ruta per a dashboard protegida amb AuthGuard
  {
    path: 'dashboard',
    loadComponent: () =>
      import('./dashboard/dashboard.component').then((m) => m.DashboardComponent),
    canActivate: [AuthGuard],
    children: [
      {
        path: 'assignatura/:id',
        loadComponent: () =>
          import('./assignatura/assignatura.component').then((m) => m.AssignaturaComponent),
      },
    ],
  },
  { path: 'login', loadComponent: () => import('./login/login.component').then((m) => m.LoginComponent) },
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: '**', redirectTo: 'login' },

];
