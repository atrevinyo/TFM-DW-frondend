import { Component, Input } from '@angular/core';
import { AlumneListComponent } from '../alumne-list/alumne-list.component';
import { ActivitatListComponent } from '../activitat-list/activitat-list.component';
import { MatTabsModule } from '@angular/material/tabs';
import { Assignatura } from '../models/models';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { AssignaturesService } from '../services/assignatures.service';

@Component({
  selector: 'app-assignatura',
  standalone: true,
  imports: [MatTabsModule, CommonModule, AlumneListComponent, ActivitatListComponent],
  templateUrl: './assignatura.component.html',
  styleUrl: './assignatura.component.css'
})
export class AssignaturaComponent {

  // @Input() assignatura: Assignatura | null = null;
  assignaturaId!: string;
  assignatura!: Assignatura |null

  constructor(private assignaturesService: AssignaturesService, private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe((params) => {
      const id = params.get('id');
      if (id) {
        this.loadAssignatura(id);
      }
    });
  }

  loadAssignatura(id: string) {
    // Utilitza el servei per obtenir l'assignatura per ID
    //AIXÒ ÉS TEMPORAL. LES ASSIGNATURES JA ESTAN AL CLIENT, NO CAL TORNAR A FER LA CRIDA
    this.assignaturesService.getAssignaturaById(id).subscribe(
      (assignatura) => {
        this.assignatura = assignatura;
      },
      (error) => {
        console.error('Error carregant assignatura:', error);
        this.assignatura = null; // En cas d'error, pots deixar assignatura com null o mostrar un missatge d'error
      }
    );
  }

}
